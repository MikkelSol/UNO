/*
*
* @Mikkel Solbakken
*
* 
* This player class is using its own stategy. 
* 1. Plays skip, reverse, or draw_two if possible.
* 2. Looks to see if I have a high Number card, if so play it. 
* 3. Plays custom card if player has less than 4 cards. 
* 4. See if I have a custom card I can play. 
* 5. play wild card if possible.
* 6. calles the color with the highest cumulative point value.  
*
*/


public class MikkelsPlayer extends SomewhatLessEagerPlayer{

   public int play(Card[] hand, Card upCard, Color calledColor, GameState state) {
   
      int num = 9;
      int index = NO_PLAY_POSSIBLE;
      
      for(int i = 0; i < hand.length; i++){   
         
         for(int j = 0; j<hand.length; j++) {
            if((hand[i].getRank().equals(Rank.SKIP) == true || (hand[i].getRank().equals(Rank.REVERSE) == true) 
            ||  (hand[i].getRank().equals(Rank.DRAW_TWO) == true)
            )
            && hand[i].canPlayOn(upCard, calledColor) ==true){
               index = i;  
               return index;
            }
         }
         
         if(hand[i].getRank().equals(Rank.WILD) == true && hand[i].canPlayOn(upCard, calledColor) == true){
            index = i;   
         }
                     
         if(hand[i].getRank().equals(Rank.NUMBER) == true){
            if(hand[i].forfeitCost() == num && hand[i].canPlayOn(upCard, calledColor) == true){
               index = i;
               return index;
            }
         }
         
         if(num > 0) {
            num--;
         }
                                 
         if(hand.length < 4 && hand[i].equals(Rank.CUSTOM) == true){
            index = i;
            return index;     
         }
         if(hand[i].getRank().equals(Rank.WILD_D4)) {
            index = super.play(hand, upCard, calledColor, state);
         }
      
      }
      
      index = super.play(hand, upCard, calledColor, state);
      
                
      return index;
   }


   public Color callColor (Card[] hand) {
   
   /* 
   *
   * When a color has to be choosen,
   * this method will choose the color that has the most cumulative point value in the hand.
   *
   */ 
   
      return super.callColor(hand);
   }
}