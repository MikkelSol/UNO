import org.junit.Assert;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import java.util.*;


public class GameTest {

   private static final Card blackHole = new Card(Color.NONE, Rank.CUSTOM);

   private static final Comparator<Card> cardComparator =
          Comparator.comparing(Card::getRank)
                  .thenComparing(Card::getColor)
                  .thenComparing(Card::getNumber);

   private static class DummyPlayer extends Player {
      @Override
      public int play(Card[] hand, Card upCard, Color calledColor, GameState state) {
         throw new RuntimeException("Should never get here");
      }
   
      @Override
      public Color callColor(Card[] hand) {
         throw new RuntimeException("Should never get here");
      }
   }

   private static class HashCard extends Card {
      public HashCard(Color color, Rank rank) {
         super(color, rank);
      }
   
      public HashCard(Color color, int number) {
         super(color, number);
      }
   
      public HashCard(Color color, Rank rank, int number) {
         super(color, rank, number);
      }
   
      public static HashCard random(Random rand) {
         Rank rank = Rank.values()[rand.nextInt(Rank.values().length)];
         Color color;
         int number;
         if (rank == Rank.WILD || rank == Rank.WILD_D4 || rank == Rank.CUSTOM) {
            // Wildcards have no color and a number of -1
            color = Color.NONE;
            number = -1;
         } else {
            // Non-wildcards have a color
            final Color[] colors = { Color.RED, Color.YELLOW, Color.GREEN, Color.BLUE };
            color = colors[rand.nextInt(colors.length)];
         
            if (rank == Rank.NUMBER)
               number = rand.nextInt(10);
            else
               // Non-number cards have no number
               number = -1;
         }
      
         return new HashCard(color, rank, number);
      }
   
      @Override
      public boolean equals(Object o) {
         if (!(o instanceof Card))
            return false;
         Card other = (Card)o;
         return getColor() == other.getColor()
                && getRank() == other.getRank()
                && getNumber() == other.getNumber();
      }
   
      @Override
      public int hashCode() {
         return Objects.hash(getColor(), getRank(), getNumber());
      }
   }

   private static Scoreboard makeScoreboard(int numPlayers) {
      String[] names = new String[numPlayers];
      for (int i = 0; i < numPlayers; ++i)
         names[i] = "" + ((char)('A' + i));
      return new Scoreboard(names);
   }

   private static Player[] makePlayers(int numPlayers) {
      Player[] players = new Player[numPlayers];
      for (int i = 0; i < numPlayers; ++i)
         players[i] = new DummyPlayer();
      return players;
   }

   @Test
   public void testBlackHole() {
      final Random random = new Random(0);
      final int NUM_TRIALS = 100;
      for (int trial = 0; trial < NUM_TRIALS; ++trial) {
         final int numPlayers = 2 + random.nextInt(5);
         Scoreboard scoreboard = makeScoreboard(numPlayers);
         Player[] players = makePlayers(numPlayers);
      
         runTrial(random, scoreboard, players);
      }
   }

   private void runTrial(Random random, Scoreboard scoreboard, Player[] players) {
      Game game = new Game(scoreboard, players);
      if (random.nextBoolean())
         game.reverseDirection();
   
      // Generate hands
      Hand[] hands = new Hand[players.length];
      List<Card> allCards = new ArrayList<>();
      for (int i = 0; i < hands.length; ++i) {
         hands[i] = new Hand(players[i], scoreboard.getPlayerList()[i]);
         int numCards = random.nextInt(10);
         for (int j = 0; j < numCards; ++j) {
            Card randomCard = HashCard.random(random);
            allCards.add(randomCard);
            hands[i].addCard(randomCard);
         }
      }
   
      Collections.sort(allCards, cardComparator);
   
      game.hands = hands;
   
      // Choose a player to play the black hole card
      int playerPlayingBlackHole = random.nextInt(players.length);
      game.currPlayer = playerPlayingBlackHole;
   
      // Play the black hole card
      try {
         game.performCardEffect(blackHole);
      } catch (DeckExhaustedException ex) {
         // Shouldn't happen - a black hole doesn't cause a draw
         // But if it does, there's something wrong....
         throw new RuntimeException(ex);
      }
   
      // Make sure that play has advanced to next player
      int expectedNextPlayer;
      if (game.direction == Direction.FORWARDS)
         expectedNextPlayer = (playerPlayingBlackHole + 1) % players.length;
      else
         expectedNextPlayer = (players.length + playerPlayingBlackHole - 1) % players.length;
   
      assertTrue("Play did not advance to next player", game.currPlayer == expectedNextPlayer);
   
      // Check that each player has the correct number of cards
      List<Card> newCards = new ArrayList<>(allCards.size());
   
      // Minimal number of cards each player should have now (in particular the one who played the black hole)
      int baseCards = allCards.size() / players.length;
      // How many extra cards should have been played out
      int extraCards = allCards.size() % players.length;
   
      // Check that each player has the correct number of cards in hand
      for (int i = 0; i < players.length; ++i) {
         int playerIndex;
         if (game.direction == Direction.FORWARDS)
            playerIndex = (playerPlayingBlackHole + i) % players.length;
         else
            playerIndex = (players.length + playerPlayingBlackHole - i) % players.length;
      
         int expectedNumCards = baseCards;
         if (i > 0 && i <= extraCards)
            ++expectedNumCards;
      
         assertEquals(String.format("After player #%d played black hole, player #%d has the wrong number of cards"
                    + " (%d players, %d total cards; play direction: %s)",
                playerPlayingBlackHole, playerIndex, players.length, allCards.size(), game.direction),
                expectedNumCards, hands[playerIndex].size());
      
         while (hands[playerIndex].size() > 0)
            newCards.add(hands[playerIndex].removeCard(0));
      }
   
      // Check that the total collection of cards is still the same
      assertEquals("After black hole, number of total cards has changed",
             allCards.size(), newCards.size());
      Collections.sort(newCards, cardComparator);
   
      assertEquals("After black hole, set of cards across all hands has changed",
             allCards, newCards);
   
   }
}