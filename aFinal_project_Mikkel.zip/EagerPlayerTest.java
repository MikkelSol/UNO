import org.junit.Assert;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.Random;

// Since EagerPlayerTest extends PlayerTest, it automatically runs all of PlayerTest's tests
public class EagerPlayerTest extends PlayerTest {

   protected EagerPlayerTest(EagerPlayer player) {
      super(player);
   }

   public EagerPlayerTest() {
      this(new EagerPlayer());
   }

   /** Test that the play() method behaves eagerly (always returns the first valid play) */
   @Test
   public void testEagerPlay() {
      // Should always return the first valid card index
      Random random = new Random(99);
      
      GameState state = new GameState();
      
      final int NUM_TRIALS = 1000;
      for (int i = 0; i < NUM_TRIALS; ++i) {
         Card upCard = randomCard(random);
         Color calledColor = randomColor(random);
         
         int handSize = random.nextInt(10) + 1;
         Card[] hand = randomHand(random, handSize);
      
         int playIndex = player.play(hand, upCard, calledColor, state);
      
         if (playIndex == Player.NO_PLAY_POSSIBLE) {
            // Check that there is no valid play possible
            for (Card handCard : hand) {
               if (handCard.canPlayOn(upCard, calledColor))
                  fail(String.format("play returned null when a play is possible (hand = %s, upCard = %s, calledColor = %s)",
                          arrayToString(hand), upCard, calledColor));
            }
         
            continue; // rest of test does not apply for this hand
         }
      
         for (int j = 0; j < playIndex; ++j) {
            assertFalse(String.format("Eager player: an earlier card can be played from this hand (hand = %s, upCard = %s, calledColor = %s; play returned %d)",
                    arrayToString(hand), upCard, calledColor, playIndex),
                    !hand[j].isWildCard() && hand[j].canPlayOn(upCard, calledColor));
         }
      }
   }
   
   /** Test that the callColor() method behaves eagerly (always returns blue) */
   @Test
   public void testEagerCallColor() {
      Random random = new Random(42);
      final int NUM_TRIALS = 1000;
      for (int i = 0; i < NUM_TRIALS; ++i) {
         int handSize = random.nextInt(10) + 1;
         Card[] hand = randomHand(random, handSize);
         
         Color called = player.callColor(hand);
         assertEquals("Eager player: returned wrong color", Color.BLUE, called);
      }
   }
}
