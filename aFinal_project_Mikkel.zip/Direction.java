public enum Direction { FORWARDS, BACKWARDS }
