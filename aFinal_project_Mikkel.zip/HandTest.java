import org.junit.Assert;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.*;

public class HandTest {

   /** Fixture initialization (common initialization
    *  for all tests). **/
   @Before public void setUp() {
   }

   /** Test the countCards method */
   @Test
   public void testCountCards() {
      Hand hand = handOf(dummyPlayer());     // empty hand
      assertEquals("Empty hand does not have zero value", 0, hand.countCards());
      
      hand = handOf(dummyPlayer(),
         new Card(Color.RED, 5),              // 5
         new Card(Color.BLUE, 0),             // 0
         new Card(Color.YELLOW, Rank.SKIP));  // 20
      assertEquals("Hand of " + hand + " incorrect value", 25, hand.countCards());
      
      hand = handOf(dummyPlayer(),
         new Card(Color.NONE, Rank.WILD),     // 50
         new Card(Color.NONE, Rank.WILD_D4),  // 50
         new Card(Color.BLUE, 1));            // 1
      assertEquals("Hand of " + hand + " incorrect value", 101, hand.countCards());
   }
   
   /** Test the play method */
   @Test
   public void testPlay() {
      runPlay(new Card(Color.RED, 8), Color.BLUE,
         array(new Card(Color.YELLOW, 4),
               new Card(Color.GREEN, 6),
               new Card(Color.GREEN, 8)),
         2, 1);
      
      // No plays possible
      runPlay(new Card(Color.RED, 8), Color.BLUE,
         array(new Card(Color.BLUE, 4),
               new Card(Color.BLUE, 2),
               new Card(Color.YELLOW, Rank.SKIP)),
         Player.NO_PLAY_POSSIBLE);
         
      runPlay(new Card(Color.RED, 8), Color.BLUE,
         array(new Card(Color.NONE, Rank.WILD),
               new Card(Color.BLUE, 0),
               new Card(Color.BLUE, 4),
               new Card(Color.BLUE, 2),
               new Card(Color.BLUE, 5)),
         0, 3, 2, 1, 0, Player.NO_PLAY_POSSIBLE);
   }
   
   /** Test the callColor method */
   @Test
   public void testCallColor() {
      Color[] colors = array(Color.RED, Color.GREEN, Color.RED, Color.YELLOW, Color.BLUE, Color.RED, Color.RED);
      
      Player p = colorPlayer(colors);
      Hand hand = new Hand(p, "Test player");
      Scoreboard sb = new Scoreboard(array("Test player"));
      Game game = new Game(sb, array(p));
      
      for (int i = 0; i < colors.length; ++i)
         assertSame("callColor returned wrong color", colors[i], hand.callColor(game));
   }
   
   private Hand handOf(Player player, Card... cards) {
      Hand hand = new Hand(player, "Test player");
      for (int i = 0; i < cards.length; ++i)
         hand.addCard(cards[i]);
      return hand;
   }
   
   @SuppressWarnings("unchecked")
   private static <T> T[] array(T... values) {
      return values;
   }
   
   /** Runs through plays of cards from a hand, checking that what the Hand says was played is what
    * the player intended.
    * upCard, calledColor: initial up card, called color for the game
    * cardsInHand: initial contents of hand
    * plays: indices of cards from hand to play. *The method does not translate these in light of plays,
    *        so they need to be the valid indices _at the time of play_.* A value of -1 means that a
    *        NoPlayPossible should be thrown.
    */
   private void runPlay(Card upCard, Color calledColor, Card[] cardsInHand, int... plays) {
      /* Things we're checking here:
       *   - Hand correctly passes on upCard, calledColor from game object
       *   - Hand returns null appropriately
       *   - Size of hand decreases by 1 with each play
       *   - Card played is correct
       */
       
      // Create the apparatus necessary for running the tests (we need a Game object to pass
      // along to the Hand even though we're not actually playing a game)
      Scoreboard board = new Scoreboard(array("Test player "));
      TestingPlayer p = new TestingPlayer(fixedPlayer(plays));
      Game game = new Game(board, array(p));
      game.upCard = upCard;
      game.calledColor = calledColor;
      Hand hand = handOf(p, cardsInHand);
      List<Card> expectedCardsInHand = new ArrayList<>(Arrays.asList(cardsInHand));
      
      for (int i = 0; i < plays.length; ++i) {
         String prePlayHand = hand.toString();
         int prePlaySize = hand.size();
         Card expected = (plays[i] == Player.NO_PLAY_POSSIBLE) ? null : expectedCardsInHand.get(plays[i]);
         p.expect(game.upCard, game.calledColor);

         Card c = hand.play(game);
         if (expected == null && c != null) {
            // Should have returned null - didn't
            fail(String.format("Hand.play() should have returned null (hand = %s; upCard = %s; calledColor = %s)",
                    prePlayHand, game.upCard, game.calledColor));
         } else if (c == null && expected != null) {
            // Should not have returned null - did
            fail(String.format("Hand.play() returned null inappropriately (hand = %s; upCard = %s; calledColor = %s)",
                    prePlayHand, game.upCard, game.calledColor));
         } else if (c != null) {
            assertEquals("Hand size did not decrease by 1 after play", prePlaySize - 1, hand.size());
            assertSame(String.format("Wrong card played from hand [%s]", prePlayHand), expected, c);
         }

         // If we get down here, everything was good for this play
         // Since we're not running an actual game, we need to manually update our state
         game.upCard = expected;
         if (plays[i] != -1)
            expectedCardsInHand.remove(plays[i]);
      }
   }
   
   private Player dummyPlayer() {
      // A dummy Player class that doesn't do anything useful (for tests that don't involve playing cards)
      class DummyPlayer extends Player {
      
         public int play(Card[] hand, Card upCard, Color calledColor, GameState state) {
            return NO_PLAY_POSSIBLE;
         }
         
         public Color callColor(Card[] hand) {
            return null;
         }
      }
      
      return new DummyPlayer();
   }
   
   private Player fixedPlayer(int... plays) {
      // A dummy Player class that makes a predefined sequence of plays (for tests that don't involve call color)
      class FixedPlayer extends Player {
      
         private int[] plays;
         private int playIndex = 0;
         
         FixedPlayer(int[] plays) {
            this.plays = plays;
         }
         
         public int play(Card[] hand, Card upCard, Color calledColor, GameState state) {
            int p = plays[playIndex];
            ++playIndex;
            return p;
         }
         
         public Color callColor(Card[] hand) {
            return null;
         }
      }
      
      return new FixedPlayer(plays);
   }
   
   private Player colorPlayer(Color... colors) {
      class ColorPlayer extends Player {
      
         private Color[] colors;
         private int index = 0;
         
         ColorPlayer(Color[] colors) {
            this.colors = colors;
         }
         
         public int play(Card[] hand, Card upCard, Color calledColor, GameState state) {
            return NO_PLAY_POSSIBLE;
         }
         
         public Color callColor(Card[] hand) {
            Color c = colors[index];
            ++index;
            return c;
         }
      }
   
      return new ColorPlayer(colors);
   }
   
   // Used by runPlay() to check that the Hand is passing along the proper upCard/callColor from the game object
   private class TestingPlayer extends Player {
      
      private Player subordinate;
      private Card expectedUpCard;
      private Color expectedCalledColor;
      
      TestingPlayer(Player subordinate) {
         this.subordinate = subordinate;
      }
      
      void expect(Card upCard, Color calledColor) {
         this.expectedUpCard = upCard;
         this.expectedCalledColor = calledColor;
      }
      
      public int play(Card[] hand, Card upCard, Color calledColor, GameState state) {
         assertEquals("Wrong up card", expectedUpCard, upCard);
         assertEquals("Wrong called color", expectedCalledColor, calledColor);
         return subordinate.play(hand, upCard, calledColor, state);
      }
      
      public Color callColor(Card[] hand) {
         return subordinate.callColor(hand);
      }
   }
}
