import org.junit.Assert;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import java.util.Random;


public class SomewhatLessEagerPlayerTest extends EagerPlayerTest {

   public SomewhatLessEagerPlayerTest() {
      super(new SomewhatLessEagerPlayer());
   }
   
   @Override
   @Test
   public void testEagerCallColor() {
      Card[] hand = array(new Card(Color.BLUE, 8));
      assertEquals(String.format("SomewhatLessEagerPlayer: callColor returned wrong color (hand = %s)", arrayToString(hand)),
                   Color.BLUE, player.callColor(hand));
      
      hand = array(new Card(Color.YELLOW, 8), new Card(Color.RED, 0), new Card(Color.RED, 5), new Card(Color.RED, 2));
      assertEquals(String.format("SomewhatLessEagerPlayer: callColor returned wrong color (hand = %s)", arrayToString(hand)),
                   Color.YELLOW, player.callColor(hand));
      
      hand = array(new Card(Color.RED, 1), new Card(Color.GREEN, Rank.SKIP), new Card(Color.RED, 9), new Card(Color.RED, 9));
      assertEquals(String.format("SomewhatLessEagerPlayer: callColor returned wrong color (hand = %s)", arrayToString(hand)),
                   Color.GREEN, player.callColor(hand));
      
      hand = array(new Card(Color.GREEN, 2), new Card(Color.GREEN, 2), new Card(Color.RED, 3));
      assertEquals(String.format("SomewhatLessEagerPlayer: callColor returned wrong color (hand = %s)", arrayToString(hand)),
                   Color.GREEN, player.callColor(hand));
      
      hand = array(new Card(Color.BLUE, 4), new Card(Color.RED, Rank.DRAW_TWO), new Card(Color.BLUE, 9), new Card(Color.YELLOW, 6), new Card(Color.BLUE, 7));
      Color called = player.callColor(hand);
      assertTrue(String.format("SomewhatLessEagerPlayer: callColor returned wrong color (hand = %s), returned %s", arrayToString(hand), called),
                 called == Color.BLUE || called == Color.RED);
   }

   @Override
   @Test
   public void testEagerPlay() {
      // Should always return the first valid card index
      Random random = new Random(99);

      GameState state = new GameState();

      final int NUM_TRIALS = 1000;
      for (int i = 0; i < NUM_TRIALS; ++i) {
         Card upCard = randomCard(random);
         Color calledColor = randomColor(random);

         int handSize = random.nextInt(10) + 1;
         Card[] hand = randomHand(random, handSize);

         int playIndex = player.play(hand, upCard, calledColor, state);

         if (playIndex == Player.NO_PLAY_POSSIBLE) {
            // Check that there is no valid play possible
            for (Card handCard : hand) {
               if (handCard.canPlayOn(upCard, calledColor))
                  fail(String.format("play returned null when a play is possible (hand = %s, upCard = %s, calledColor = %s)",
                          arrayToString(hand), upCard, calledColor));
            }

            continue; // rest of test does not apply for this hand
         }

         boolean handHasCustomCard = false;
         for (Card card : hand) {
            if (card.getRank() == Rank.CUSTOM)
               handHasCustomCard = true;
         }

         // If there is a custom card in the hand, make sure they play it!
         if (handHasCustomCard && hand[playIndex].getRank() != Rank.CUSTOM)
            fail(String.format("Somewhat eager player: custom card available but it was not played (hand = %s, upCard = %s, calledColor = %s; play returned %d)",
                    arrayToString(hand), upCard, calledColor, playIndex));
         else if (!handHasCustomCard) {
            // Otherwise it should play the first available card
            for (int j = 0; j < playIndex; ++j) {
               assertFalse(String.format("Somewhat eager player: an earlier card can be played from this hand (hand = %s, upCard = %s, calledColor = %s; play returned %d)",
                       arrayToString(hand), upCard, calledColor, playIndex),
                       !hand[j].isWildCard() && hand[j].canPlayOn(upCard, calledColor));
            }
         }
      }
   }
   
   @SuppressWarnings("unchecked")
   private static <T> T[] array(T... values) {
      return values;
   }
}
