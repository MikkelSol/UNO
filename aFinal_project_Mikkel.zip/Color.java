public enum Color { RED, YELLOW, GREEN, BLUE, NONE }
