/**
 * @Mikkel Solbakken 
 * 
 * <p>A Card in an Uno deck. Each Card knows its particular type, which is
 * comprised of a 3-tuple (color, rank, number). Not all of these values
 * are relevant for every particular type of card, however; for instance,
 * wild cards have no color (getColor() will return Color.NONE) or number
 * (getNumber() will return -1).</p>
 * <p>A Card knows its forfeit cost (<i>i.e.</i>, how many points it counts
 * against a loser who gets stuck with it) and how it should act during
 * game play (whether it permits the player to change the color, what
 * effect it has on the game state, etc.)</p>
 * @since 1.0
 *
 * 
 */
public class Card {

   /** 
   * Instance variables:
   */
   
   private Color color;
   private Rank rank;
   private int number;

   /**
    * Constructor for non-number cards (skips, wilds, etc.)
    */
   public Card(Color color, Rank rank) {   
      this.color = color;
      this.rank = rank;
      this.number = -1;  
   }

   /**
    * Constructor for number cards.
    */
   public Card(Color color, int number) {
      this.color = color;
      this.rank = Rank.NUMBER;   
      this.number = number; 
   }

   /**
    * Constructor to explicitly set entire card state.
    */
   public Card(Color color, Rank rank, int number) {
      this.color = color;
      this.rank = rank;    
      this.number = number;    
   }

   /**
    * Returns the number of points this card will count against a player
    * who holds it in his/her hand when another player goes out.
    */
   public int forfeitCost() {
      if(rank == Rank.SKIP || rank == Rank.REVERSE || rank == Rank.DRAW_TWO) {
         return 20; 
      }
   
      if(rank == Rank.WILD || rank == Rank.WILD_D4 || rank == Rank.CUSTOM) {
         return 50;  
      } 
      
      if(rank == Rank.NUMBER) {
         return number;
      } 
      
      return -10000;
   }

   /**
    * Returns true only if this Card can legally be played on the up card
    * passed as an argument. The second argument is relevant only if the
    * up card is a wild.
    * @param upCard An "up card" upon which the current object might (or might
    * not) be a legal play.
    * @param calledColor If the up card is a wild card, this parameter
    * contains the color the player of that color called.
    */ 
   public boolean canPlayOn(Card upCard, Color calledColor) {
      Color saveColor;
      
      if(this.rank == Rank.WILD || this.rank == Rank.WILD_D4 || this.rank == Rank.CUSTOM){
         return true;
      }
   
      if(this.number == upCard.getNumber() && this.number != -1 && upCard.getNumber() != -1) {
         return true;
      }
      if (upCard.isWildCard()){
         saveColor = calledColor;
      }
      else { 
         saveColor = upCard.getColor();
      } 
            
      if(this.color == saveColor){
         return true;
      }
      if(this.rank == upCard.getRank() && this.rank!= Rank.NUMBER && upCard.getRank()!= Rank.NUMBER){
         return true;
      }
      return false;
   }

   /**
    * Returns true only if playing this Card object would result in the
    * player being asked for a color to call. (In the standard game, this
    * is true only for wild cards.)
    */
   public boolean isWildCard() {
      return rank == Rank.WILD || rank == Rank.WILD_D4 || rank == Rank.CUSTOM;
   }

   /**
    * Returns the color of this card, which is Color.NONE in the case of
    * wild cards.
    */
   public Color getColor() {
      if(rank == Rank.WILD || rank == Rank.WILD_D4 || rank == Rank.CUSTOM) {
         color = Color.NONE;
      }          
      return color;
   }

   /**
    * Returns the rank of this card, which is Rank.NUMBER in the case of
    * number cards (calling getNumber() will retrieve the specific
    * number.)
    */
   public Rank getRank() {         
      return rank;
   }



   /**
    * Returns the number of this card, which is guaranteed to be -1 for
    * non-number cards (cards of non-Rank.NUMBER rank.)
    */
   public int getNumber() {
      return number;
   }

   /**
    * Returns this Card object as a string. 
    */
   public String toString() {   
      String print = "";
   
      switch(color){
         case RED:
            print += "red";
            break;
         case YELLOW:
            print += "yellow";
            break;
         case GREEN:
            print += "green";
            break;
         case BLUE:
            print += "blue";
            break;
         case NONE:
            print += "";
            break;
      }
      
      switch(rank) {
         case NUMBER: 
            print += " " + number;
            break; 
         case SKIP: 
            print += " skip"; 
            break; 
         case REVERSE: 
            print += " reverse"; 
            break; 
         case DRAW_TWO: 
            print += " draw 2";
            break; 
         case WILD: 
            print += "wild";
            break; 
         case WILD_D4: 
            print += "wild 4";  
            break; 
         case CUSTOM: 
            print += "black hole"; 
            break;           
      }   
      return print; 
   }  
}
