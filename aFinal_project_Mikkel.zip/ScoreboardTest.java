import org.junit.Assert;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.Arrays;
import java.util.Random;


public class ScoreboardTest {

   private final String[] playerNames = {
      "John", "Susan", "Michael", "Delenn", "Na'toth"
   };
   
   // Make a copy of playerNames so that we can detect if the constructor
   // futzes with the original
   private final String[] playerNamesCopy = Arrays.copyOf(playerNames, playerNames.length);
   
   private Scoreboard scoreboard;

   /** Fixture initialization (common initialization
    *  for all tests). **/
   @Before
   public void setUp() {
      scoreboard = new Scoreboard(playerNames);
   }


   /** Checks that the constructor doesn't mess with the parameter array **/
   @Test
   public void testConstructor() {
      assertArrayEquals("playerNames array changed by constructor", playerNamesCopy, playerNames);
   }
   
   /** Tests the accessors, getNumPlayers and getPlayerList */
   @Test
   public void testAccessors() {
      assertEquals("getNumPlayers result incorrect", playerNamesCopy.length, scoreboard.getNumPlayers());
      assertArrayEquals("getPlayerList result incorrect", playerNamesCopy, scoreboard.getPlayerList());
   }
   
   /** Tests getScore and addToScore */
   @Test
   public void testScoring() {
      final int BOUND = 1000000; // max number of points to award
      Random random = new Random(10);
      
      // Initially they should all have 0 points
      // Also give points while we do this for checking in the next part
      for (int i = 0; i < playerNamesCopy.length; ++i) {
         assertEquals("Player " + i + " points incorrect initially", 0, scoreboard.getScore(i));
         
         // Add a random number of points several times
         for (int j = 0; j < 5; ++j)
            scoreboard.addToScore(i, random.nextInt(BOUND));
      }
      
      // Do they have the right numbers of points?
      random = new Random(10); // Recreate the PRNG so we get the same numbers
      for (int i = 0; i < playerNamesCopy.length; ++i) {
         // Compute again how many points this player should have
         int correctScore = 0;
         for (int j = 0; j < 5; ++j)
            correctScore += random.nextInt(BOUND);
            
         assertEquals("Player " + i + " points incorrect after calling addToScore",
            correctScore, scoreboard.getScore(i));
      }
   }
   
   /** Add some points and test getWinner */
   @Test
   public void testGetWinner() {
      scoreboard.addToScore(0, 20);
      scoreboard.addToScore(1, 40);
      scoreboard.addToScore(2, 60);
      assertEquals("getWinner returning wrong result; scores were " + scoreboard, 2, scoreboard.getWinner());
      
      scoreboard.addToScore(1, 60);
      assertEquals("getWinner returning wrong result; scores were " + scoreboard, 1, scoreboard.getWinner());
      
      scoreboard.addToScore(2, 41);
      assertEquals("getWinner returning wrong result; scores were " + scoreboard, 2, scoreboard.getWinner());
      
      scoreboard.addToScore(1, 1);
      int winner = scoreboard.getWinner();
      assertTrue("getWinner should have returned 1 or 2; scores were " + scoreboard, 
         winner == 1 || winner == 2);
   }
}
