public class MikkelsPlayertest extends PlayerTest {

   public MikkelsPlayertest() {
      super(new MikkelsPlayer());
   }
}