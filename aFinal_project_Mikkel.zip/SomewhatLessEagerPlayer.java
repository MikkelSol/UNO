/*
* @Mikkel Solbakken
*
* This class plays the custom card (Black Hole) whenever it is in the players hand,
* if not then it will look at its parent class, "EagerPlayer" and see if there is cards that can be played. 
*
* If a color has to be called, it will call the color with highest cumulative value in the hands if tied. 
*
*/


public class SomewhatLessEagerPlayer extends EagerPlayer{

   public int play(Card[] hand, Card upCard, Color calledColor, GameState state) {
   
      
      int index = NO_PLAY_POSSIBLE;
      
      for(int i = 0; i < hand.length; i++){
         if(hand[i].getRank().equals(Rank.CUSTOM) == true){
            index = i;
            return index;
         }
      }
     
      index = super.play(hand, upCard, calledColor, state);
      return index;
   }


   public Color callColor (Card[] hand) {
   
   
   /* 
   *
   * When a color has to be choosen,
   * this method will choose the color that has the most cumulative point in the hand.
   *
   */ 
      int blueValue = 0;
      int greenValue = 0;
      int redValue = 0; 
      int yellowValue = 0;
   
   
      for(int i = 0; i < hand.length; i++) {
         if(hand[i].getColor() == Color.BLUE){
            blueValue += hand[i].forfeitCost();
         }
         
         if(hand[i].getColor() == Color.GREEN){
            greenValue += hand[i].forfeitCost();
         }
            
         if(hand[i].getColor() == Color.RED){
            redValue += hand[i].forfeitCost();
         }
      
         if(hand[i].getColor() == Color.YELLOW){
            yellowValue += hand[i].forfeitCost();
         }  
      }
      
      
      if(blueValue >= greenValue && blueValue >= redValue && blueValue >= yellowValue){
         return Color.BLUE;
      }
      
      else if(greenValue >= blueValue && greenValue >= redValue && greenValue >= yellowValue) {   
         return Color.GREEN;
      }
      
      else if(redValue >= blueValue && redValue >= greenValue && redValue >= yellowValue) {
         return Color.RED;
      }
      
      else {
         return Color.YELLOW;
      }  
   }
}