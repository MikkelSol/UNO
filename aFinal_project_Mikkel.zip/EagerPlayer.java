/**
* @Mikkel Solbakken 
* 
* This class returns the first index that can be played if not it returns NO_PLAY_POSSIBLE
* If a color has to be called, then it calles Color.BLUE
*
*/

public class EagerPlayer extends Player {
   public int play (Card[] hand, Card upCard, Color calledColor, GameState state) {
   
      /* HERE IS WHERE THE STRATEGY WILL GO */
      
      int index = this.NO_PLAY_POSSIBLE;
   
   
      for(int i = 0; i < hand.length; i++){
         
         // if the hand is not a WILD_D4, and you can play; index = i.
         if(hand[i].getRank().equals(Rank.WILD_D4) == false && hand[i].canPlayOn(upCard,calledColor)== true){
            index = i;
            return index;
         }
         
      /*
      * If the hand is a WILD_D4, return the index of that number, the loop will then do the loop again 
      * and check if the next card is something that can be played instead. If not then it will 
      * use the index in the if statement below. 
      */          
       
                   
         if(hand[i].getRank().equals(Rank.WILD_D4)){
            index = i;
         }
      }
      return index;
   }
   
            
                  
   public Color callColor (Card[] hand) {
      
      return Color.BLUE;
   
   }
   
         
   
   
}

