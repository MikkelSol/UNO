import org.junit.Assert;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.Random;

/**
 * NOTE: This test uses Card.canPlayOn and Card.isWildCard extensively. If your code's version of these methods is
 * wrong, then your Player may have errors that this test will not catch. Make sure your Card class passes the unit
 * tests before running this!
 */
public abstract class PlayerTest {

   protected Player player;
   
   protected PlayerTest(Player player) {
      this.player = player;
   }
   
   /** Test the play method.*/
   @Test
   public void testPlay() {
      /* Things this test checks:
       * - play() returns a valid index
       * - play() returns index of a card that can actually be played
       * - if play() returns null, it's actually the case that no play is possible
       * - play() returns a wildcard only when no other play is possible
       *
       * What this test does -not- check:
       * - any nontrivial use of the GameState (an empty GameState is passed to play())
       */
      Random random = new Random(144); // use a fixed seed so we always get the same "random" numbers/cards
      
      GameState state = new GameState();
      final int NUM_TRIALS = 1000; // how many tests to run
      
      for (int i = 0; i < NUM_TRIALS; ++i) {
         Card upCard = randomCard(random);
         Color called = randomColor(random);
         int handSize = random.nextInt(10) + 1; // how many cards in hand
         Card[] hand = randomHand(random, handSize);
         
         int playIndex = player.play(hand, upCard, called, state);
         assertTrue(String.format("play returned index " + playIndex + " (hand = %s)", arrayToString(hand)),
                    playIndex == Player.NO_PLAY_POSSIBLE || (playIndex >= 0 && playIndex < handSize));

         if (playIndex == Player.NO_PLAY_POSSIBLE) {
            // Make sure that no play is possible
            for (Card handCard : hand) {
               if (handCard.canPlayOn(upCard, called)) {
                  fail(String.format("play returned null when a play is possible (hand = %s, upCard = %s, calledColor = %s)",
                          arrayToString(hand), upCard, called));
               }
            }
         } else {
            Card played = hand[playIndex];
            assertTrue(String.format("play chose a card that cannot be played (upCard = %s, calledColor = %s): %s",
                    upCard, called, played), played.canPlayOn(upCard, called));

            // If it's a draw 4 wildcard, make sure there was no card in hand of applicable color
            if (played.getRank() == Rank.WILD_D4) {
               if (!isWildDraw4Allowed(hand, upCard, called))
                  fail(String.format("play chose a draw 4 wild when an applicable card is available (hand = %s, upCard = %s, calledColor = %s): %s",
                          arrayToString(hand), upCard, called, played));
            }
         }
      }
   }

   /** Test the callColor method. */
   @Test
   public void testCallColor() {
      Random random = new Random(47); // use a fixed seed so we always get the same "random" numbers
      
      final int NUM_TRIALS = 1000; // how many tests to run
      for (int i = 0; i < NUM_TRIALS; ++i) {
         int handSize = random.nextInt(10) + 1;
         Card[] hand = randomHand(random, handSize);
         
         Color called = player.callColor(hand);
         if (called == null || called == Color.NONE)
            fail("callColor returned " + called);
      }
   }
   
   protected Card[] randomHand(Random random, int size) {
      Card[] cards = new Card[size];
      for (int i = 0; i < size; ++i)
         cards[i] = randomCard(random);
      return cards;
   }
   
   protected Card randomCard(Random random) {
      int cardType = random.nextInt(16);
      if (cardType < 10)
         return new Card(randomColor(random), cardType);
      else if (cardType == 10)
         return new Card(randomColor(random), Rank.SKIP);
      else if (cardType == 11)
         return new Card(randomColor(random), Rank.REVERSE);
      else if (cardType == 12)
         return new Card(randomColor(random), Rank.DRAW_TWO);
      else if (cardType == 13)
         return new Card(Color.NONE, Rank.WILD);
      else if (cardType == 14)
         return new Card(Color.NONE, Rank.WILD_D4);
      else
         return new Card(Color.NONE, Rank.CUSTOM);
   }
   
   protected Color randomColor(Random random) {
      Color[] colors = { Color.RED, Color.YELLOW, Color.GREEN, Color.BLUE };
      
      return colors[random.nextInt(colors.length)];
   }
      
   protected static <T> String arrayToString(T[] values) {
      StringBuilder sb = new StringBuilder().append('[');
      for (int i = 0; i < values.length; ++i) {
         if (i > 0)
            sb.append(", ");
         sb.append(values[i]);
      }
      
      return sb.append("]").toString();
   }

   // Returns the effective upcolor (upCard's color if it has one, otherwise called color)
   protected Color effectiveColor(Card upCard, Color called) {
      return upCard.isWildCard() ? called : upCard.getColor();
   }

   // Returns whether it is current allowed to play a wild draw 4 (official Uno rules say this is only possible if no
   // card in hand is of same color as upcard)
   protected boolean isWildDraw4Allowed(Card[] hand, Card upCard, Color called) {
      Color color = effectiveColor(upCard, called);
      for (Card card : hand) {
         if (card.getColor() == color)
            return false;
      }

      return true;
   }
}
