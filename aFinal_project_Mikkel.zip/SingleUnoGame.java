/**
 * @Mikkel Solbakken
 *
 * A class for playing a single Uno game.
 */
public class SingleUnoGame {

   private Scoreboard scoreboard;
   private Player[] players;

   /**
    * Creates a new SingleUnoGame.
    * @param scoreboard the scoreboard to use to keep score
    * @param players the players playing the game
    */
   public SingleUnoGame(Scoreboard scoreboard, Player[] players) {
      
      this.scoreboard = scoreboard;
      this.players = players;
      
   }
   
   /**
    * Returns the game's scoreboard.
    */
   public Scoreboard getScoreboard() {
      return this.scoreboard;
   }
   
   /**
    * Returns the game's players.
    */
   public Player[] getPlayers() {
      return this.players;
   }
   
   /**
    * Plays a single round of Uno. The winner can be determined by calling the
    * scoreboard's getWinner method.
    */
   public void playGame() {
   
      Game gameobject1 = new Game(scoreboard, players);
      gameobject1.play();
   }

   public static void main(String[] args) {
      // Fill this in with your Player classes to run a four-player Uno game.
      String[] players = {"A", "B", "C", "D"}; 
      
      // Set the PRINT_VERBOSE class variable in Game to true to tell it to
      // display the details of the game.
      Game.PRINT_VERBOSE = true;
      
      // You will need to create a Scoreboard and an array of Players, then
      // create a new SingleUnoGame object and call its playGame method.
      Scoreboard scoreboard1 = new Scoreboard(players);
      Player[] playerObjects = {
         
         new EagerPlayer(), 
         new MikkelsPlayer(), 
         new EagerPlayer(), 
         new EagerPlayer()};
      
      SingleUnoGame game = new SingleUnoGame(scoreboard1, playerObjects);
      
      game.playGame();
      
      // When done, display the scoreboard.
      System.out.println(scoreboard1);
      
   }
}